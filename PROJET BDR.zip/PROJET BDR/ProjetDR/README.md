NB: Si tu as des soucis , sans doute du à la creation de repertoire ou au chemin sur windows donc fais gaffe.

version minmale de javba: java 17 


Si tu as des soucis à la compilation (qui peut arriver car je sais pas trop comment est l environnement java chez toi), j ai generé les classes au cas où ET TU POURRAS DIRECTEMENT PASSER A  L EXECUTION (avec java supérieure à 17)


POUR COMPILER 
javac -source 17 -target 17 -d out -sourcepath src src/Diary/DiaryServer.java src/daemon/Daemon.java src/model/*.java src/interfaces/*.java src/downloader/Downloader.java src/model/ClientMain.java
javac -source 17 -target 17 -d out -sourcepath src src/model/ClientMain.java
java -cp out Diary.DiaryServer


EXECUTION


tu peux juste te placer dans le repertoire du projet, lancer 

java -cp out model.ClientMain 10.192.116.133 shared1
java -cp out model.ClientMain shared2
java -cp out model.ClientMain shared


java -Djava.security.policy=rmi.policy DiaryServer
python3 delete_repo.py --aws_access_key_id AKIAYDWHTDEGZUQHKVXP --aws_secret_access_key 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
python3 main.py --aws_access_key_id AKIAYDWHTDEGZUQHKVXP --aws_secret_access_key 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
python3 launch_client.py --aws_access_key_id AKIAYDWHTDEGZUQHKVXP --aws_secret_access_key 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
python3 n7.py --aws_access_key_id AKIAYDWHTDEGZUQHKVXP --aws_secret_access_key 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
et execute dans le terminal où tu as lancé java -cp out model.ClientMain shared un telechargement 

 ssh -i "SERVEUR_RMI.pem" ubuntu@ec2-35-180-230-215.eu-west-3.compute.amazonaws.com

 chmod +x test.sh
./test.sh




