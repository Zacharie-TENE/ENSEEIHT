import paramiko
import json
import boto3
import argparse
import subprocess

def load_instances():
    with open('instances.json', 'r') as f:
        return json.load(f)

def create_ssh_client(instance_ip, username, key_file):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(instance_ip, username=username, key_filename=key_file)
    return ssh

def run_command(ssh, command):
    stdin, stdout, stderr = ssh.exec_command(command)
    exit_status = stdout.channel.recv_exit_status()
    if exit_status != 0:
        print(f"Command '{command}' failed with exit status {exit_status}")
    return stdout.read().decode(), stderr.read().decode()

def deploy_and_run_project(instance_ip, username, key_file, project_dir, server_ip, shared_dir):
    command = f"ssh -i {key_file} {username}@{instance_ip} 'java -cp {project_dir}/out model.ClientMain {server_ip} {shared_dir}'"
    print(f"Running command on {instance_ip}: {command}")
    subprocess.Popen(["gnome-terminal", "--", "bash", "-c", command])

def run_project_on_instances(instances, username, key_file, project_dir, server_ip, shared_dir, n=5):
    instances_to_process = instances[:n]
    for instance in instances_to_process:
        public_dns = instance.public_dns_name
        print(f"Opening SSH terminal for instance: {public_dns}")
        deploy_and_run_project(public_dns, username, key_file, project_dir, server_ip, shared_dir)

def get_ec2_instances(instance_info, aws_access_key_id, aws_secret_access_key):
    instances = []
    for info in instance_info:
        session = boto3.Session(
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            region_name=info['region']  # Utiliser la région de l'instance
        )
        ec2_resource = session.resource('ec2')
        instance = ec2_resource.Instance(info['id'])
        instances.append(instance)
    return instances

def start_rmi_server(instance_id, aws_access_key_id, aws_secret_access_key, username, key_file, project_dir):
    session = boto3.Session(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        region_name='us-east-1'  # Remplacez par la région de votre instance
    )
    ec2_resource = session.resource('ec2')
    instance = ec2_resource.Instance(instance_id)

    # Attendre que l'instance soit dans l'état 'running'
    instance.wait_until_running()

    # Récupérer l'adresse IP publique
    instance.reload()
    public_ip = instance.public_ip_address

    # Créer une connexion SSH
    ssh = create_ssh_client(public_ip, username, key_file)

    # Lancer le serveur RMI
    command = f"java -cp {project_dir}/out Diary.DiaryServer"
    stdout, stderr = run_command(ssh, command)
    print(stdout)
    print(stderr)

    return public_ip

def parse_arguments():
    parser = argparse.ArgumentParser(description="Download GitHub script.")
    parser.add_argument('--aws_access_key_id', type=str, help="AWS Access Key ID")
    parser.add_argument('--aws_secret_access_key', type=str, help="AWS Secret Access Key")
    return parser.parse_args()

if __name__ == "__main__":
    args = parse_arguments()
    aws_access_key_id = args.aws_access_key_id
    aws_secret_access_key = args.aws_secret_access_key
    all_instances_info = load_instances()

    rmi_server_instance_id = "i-02a3ee6a334f2c4db"  # Remplacez par l'ID de votre instance RMI
    username = "ubuntu"
    key_file = "my-ec2-key-paire.pem"
    project_dir = "~/ProjetDR"

    # Démarrer le serveur RMI et récupérer son adresse IP publique
    server_ip = start_rmi_server(rmi_server_instance_id, aws_access_key_id, aws_secret_access_key, username, "SERVEUR_RMI.perm", project_dir)

    # Obtenir les autres instances
    all_instances = get_ec2_instances(all_instances_info, aws_access_key_id, aws_secret_access_key)

    shared_dir = "ProjetDR/shared1"
    n = int(input("Enter le nombre d instance (<32): "))
    run_project_on_instances(all_instances, username, key_file, project_dir, server_ip, shared_dir, n)