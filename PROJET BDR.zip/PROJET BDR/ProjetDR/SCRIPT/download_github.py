import paramiko
import json
import boto3
import logging
import os
import argparse

# Configuration du journal
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

def load_instances(file_path='instances.json'):
    """Charge les informations des instances EC2 à partir d'un fichier JSON."""
    try:
        with open(file_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        logger.error(f"Le fichier {file_path} est introuvable.")
        return []
    except json.JSONDecodeError:
        logger.error(f"Erreur lors du décodage du fichier {file_path}.")
        return []

def create_ssh_client(instance_ip, username, key_file):
    """Crée un client SSH pour se connecter à une instance EC2."""
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(instance_ip, username=username, key_filename=key_file, timeout=10)
        logger.info(f"Connexion SSH établie avec {instance_ip}.")
        return ssh
    except Exception as e:
        logger.error(f"Échec de la connexion SSH avec {instance_ip}: {e}")
        return None

def run_command(ssh, command):
    """Exécute une commande sur une session SSH."""
    try:
        stdin, stdout, stderr = ssh.exec_command(command)
        exit_status = stdout.channel.recv_exit_status()
        stdout_output = stdout.read().decode()
        stderr_output = stderr.read().decode()
        if exit_status == 0:
            logger.info(f"Commande réussie : {command}")
        else:
            logger.error(f"Commande échouée : {command}\nErreur : {stderr_output}")
        return stdout_output, stderr_output
    except Exception as e:
        logger.error(f"Erreur lors de l'exécution de la commande '{command}': {e}")
        return "", str(e)

def clone_repository(ssh, repo_url):
    """Clône un dépôt Git sur l'instance distante."""
    # Ajouter l'hôte GitHub à known_hosts
    keyscan_cmd = 'ssh-keyscan -t rsa github.com >> ~/.ssh/known_hosts'
    stdout, stderr = run_command(ssh, keyscan_cmd)
    if "github.com" not in stdout and "github.com" not in stderr:
        logger.error("Échec de l'ajout de GitHub à known_hosts.")
        return
    else:
        logger.info("Hôte GitHub ajouté avec succès à known_hosts.")
    
    # Ajouter la clé SSH
    ssh_key_cmd = 'eval "$(ssh-agent -s)" && ssh-add ~/.ssh/id_rsa'
    stdout, stderr = run_command(ssh, ssh_key_cmd)
    if "Error" in stderr or not stdout:
        logger.error("L'ajout de la clé SSH a échoué.")
        return
    
    # Cloner le dépôt
    clone_cmd = f"git clone {repo_url}"
    stdout, stderr = run_command(ssh, clone_cmd)
    if "fatal" in stderr:
        logger.error(f"Échec du clonage du dépôt {repo_url}: {stderr}")


def clone_repo_on_all_instances(instances, username, key_file, repo_url):
    """Clône un dépôt Git sur toutes les instances EC2 spécifiées."""
    for instance in instances:
        public_dns = instance.public_dns_name
        if not public_dns:
            logger.warning(f"L'instance {instance.id} n'a pas de DNS public.")
            continue

        ssh = create_ssh_client(public_dns, username, key_file)
        if ssh:
            clone_repository(ssh, repo_url)
            ssh.close()
        else:
            logger.error(f"Connexion impossible pour l'instance {instance.id}.")

def get_ec2_instances(instance_info,aws_access_key_id, aws_secret_access_key):
    """Récupère les objets d'instance EC2 depuis AWS."""
    instances = []
    for info in instance_info:
        try:
            session = boto3.Session(
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
                region_name=info['region']
            )
            ec2_resource = session.resource('ec2')
            instance = ec2_resource.Instance(info['id'])
            if instance.state['Name'] == 'running':
                instances.append(instance)
            else:
                logger.warning(f"L'instance {info['id']} n'est pas en cours d'exécution (statut: {instance.state['Name']}).")
        except Exception as e:
            logger.error(f"Erreur lors de la récupération de l'instance {info['id']}: {e}")
    return instances

def parse_arguments():
    parser = argparse.ArgumentParser(description="Download GitHub script.")
    parser.add_argument('--aws_access_key_id', type=str, help="AWS Access Key ID")
    parser.add_argument('--aws_secret_access_key', type=str, help="AWS Secret Access Key")
    return parser.parse_args()

if __name__ == "__main__":
    args = parse_arguments()
    aws_access_key_id=args.aws_access_key_id
    aws_secret_access_key=args.aws_secret_access_key
    # Charger les informations des instances EC2
    all_instances_info = load_instances()
    if not all_instances_info:
        logger.error("Aucune instance à traiter.")
        exit(1)

    # Vérifier la clé privée
    key_file = "my-ec2-key-paire.pem"
    if not os.path.exists(key_file):
        logger.error(f"Le fichier de clé privée '{key_file}' est introuvable.")
        exit(1)

    # Vérifier l'URL du dépôt
    repo_url = "git@github.com:JustinienC/ProjetDR.git"
    if not repo_url.startswith("git@"):
        logger.error(f"L'URL du dépôt '{repo_url}' est invalide.")
        exit(1)

    # Obtenir les instances EC2
    all_instances = get_ec2_instances(all_instances_info,aws_access_key_id, aws_secret_access_key)
    if not all_instances:
        logger.error("Aucune instance EC2 active n'a été trouvée.")
        exit(1)

    # Cloner le dépôt sur toutes les instances
    username = "ubuntu"
    clone_repo_on_all_instances(all_instances, username, key_file, repo_url)
