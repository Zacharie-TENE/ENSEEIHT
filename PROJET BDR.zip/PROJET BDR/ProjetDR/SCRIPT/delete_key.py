import boto3

def delete_key_pair_all_regions(key_name, aws_access_key, aws_secret_key):
    """
    Delete a key pair with the specified name from all AWS regions
    
    Parameters:
    key_name (str): Name of the key pair to delete
    aws_access_key (str): AWS access key ID
    aws_secret_key (str): AWS secret access key
    """
    
    # List of all AWS regions
    regions = [
        'eu-west-3', 'eu-west-1', 'eu-west-2', 'eu-north-1', 'sa-east-1', 
        'ap-south-1', 'ap-northeast-3', 'ap-northeast-2', 'ap-northeast-1', 
        'ap-southeast-1', 'ap-southeast-2', 'ca-central-1', 'eu-central-1', 
        'us-east-2', 'us-east-1', 'us-west-2', 'us-west-1'
    ]

    for region in regions:
        try:
            # Create AWS session for the region
            session = boto3.Session(
                aws_access_key_id=aws_access_key,
                aws_secret_access_key=aws_secret_key,
                region_name=region
            )
            
            # Create EC2 client
            ec2_client = session.client('ec2')
            
            try:
                # Check if key pair exists in this region
                ec2_client.describe_key_pairs(KeyNames=[key_name])
                
                # Delete the key pair
                ec2_client.delete_key_pair(KeyName=key_name)
                print(f"Successfully deleted key pair '{key_name}' in region {region}")
                
            except ec2_client.exceptions.ClientError as e:
                if e.response['Error']['Code'] == 'InvalidKeyPair.NotFound':
                    print(f"Key pair '{key_name}' not found in region {region}")
                else:
                    print(f"Error checking/deleting key pair in region {region}: {str(e)}")
                    
        except Exception as e:
            print(f"Error accessing region {region}: {str(e)}")

if __name__ == "__main__":
    # AWS credentials
    aws_access_key = "AKIAYDWHTDEGZUQHKVXP"
    aws_secret_key = "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"
    
    # Key pair name to delete
    key_name = "my-ec2-key-paire"
    
    # Delete key pair from all regions
    delete_key_pair_all_regions(key_name, aws_access_key, aws_secret_key)