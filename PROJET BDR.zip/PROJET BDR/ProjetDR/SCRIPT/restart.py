import boto3
import time

# Liste des régions à parcourir
regions = [
    'eu-central-1', 'eu-west-3', 'eu-west-1', 'eu-west-2', 'eu-north-1', 'sa-east-1', 
    'ap-south-1', 'ap-northeast-3', 'ap-northeast-2', 'ap-northeast-1', 
    'ap-southeast-1', 'ap-southeast-2', 'ca-central-1', 
    'us-east-2', 'us-east-1', 'us-west-2', 'us-west-1'
]

def restart_all_instances(aws_access_key, aws_secret_key):
    for region in regions:
        print(f"Restarting instances in region: {region}")
        try:
            # Créer une session AWS pour la région spécifique
            session = boto3.Session(
                aws_access_key_id=aws_access_key,
                aws_secret_access_key=aws_secret_key,
                region_name=region
            )
            ec2_client = session.client('ec2')
            
            # Décrire toutes les instances en cours d'exécution
            response = ec2_client.describe_instances(
                Filters=[{'Name': 'instance-state-name', 'Values': ['running']}]
            )
            
            # Collecter tous les IDs des instances
            instance_ids = [
                instance['InstanceId']
                for reservation in response['Reservations']
                for instance in reservation['Instances']
            ]
            
            if instance_ids:
                print(f"Stopping instances: {instance_ids}")
                ec2_client.stop_instances(InstanceIds=instance_ids)
                
                # Attendre que toutes les instances soient arrêtées
                waiter = ec2_client.get_waiter('instance_stopped')
                waiter.wait(InstanceIds=instance_ids)
                print(f"Instances stopped successfully in region {region}")
                
                # Redémarrer les instances arrêtées
                print(f"Starting instances: {instance_ids}")
                ec2_client.start_instances(InstanceIds=instance_ids)
                print(f"Instances started successfully in region {region}")
            else:
                print(f"No running instances found in region {region}")
        
        except Exception as e:
            print(f"Error restarting instances in region {region}: {str(e)}")

if __name__ == "__main__":
    aws_access_key = "AKIAYDWHTDEGZUQHKVXP"
    aws_secret_key = '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'

    restart_all_instances(aws_access_key, aws_secret_key)