import paramiko
import os
import time
import json
import boto3
import argparse

GITHUB_KEY = "github.com ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCj7ndNxQowgcQnjshcLrqPEiiphnt+VTTvDP6mHBL9j1aNUkY4Ue1gvwnGLVlOhGeYrnZaMgRK6+PKCUXaDbC7qtbW8gIkhL7aGCsOr/C56SJMy/BCZfxd1nWzAOxSDPgVsmerOBYfNqltV9/hWCqBywINIR+5dIg6JTJ72pcEpEjcYgXkE2YEFXV1JHnsKgbLWNlhScqb2UmyRkQyytRLtL+38TGxkxCflmO+5Z8CSSNY7GidjMIZ7Q4zMjA2n1nGrlTDkzwDCsw+wqFPGQA179cnfGWOWRVruj16z6XyvxvjJwbz0wQZ75XK5tKSb7FNyeIEs4TT4jk+S4dhPeAUC5y+bDYirYgM4GC7uEnztnZyaVWQ7B381AK4Qdrwt51ZqExKbQpTUNn+EjqoTwvqNj4kqx5QUCI0ThS/YkOxJCXmPUWZbhjpCg56i+2aB6CmK2JGhn57K5mj0MNdBXA4/WnwH6XoPWJzK5Nyu2zB3nAZp+S5hpQs+p1vN1/wsjk="

def create_ssh_client(instance_ip, username, key_file):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(instance_ip, username=username, key_filename=key_file)
    return ssh

def load_instances():
    with open('instances.json', 'r') as f:
        return json.load(f)
    
def run_command(ssh, command):
    stdin, stdout, stderr = ssh.exec_command(command)
    exit_status = stdout.channel.recv_exit_status()
    if exit_status != 0:
        print(f"Command '{command}' failed with exit status {exit_status}")
    return stdout.read().decode(), stderr.read().decode()

def transfer_ssh_key(instance_ip, username, local_key_path, key_file):
    retries = 5
    for attempt in range(retries):
        scp_command = f"scp -i {key_file} {local_key_path} {username}@{instance_ip}:~/.ssh/id_rsa"
        result = os.system(scp_command)
        if result == 0:
            ssh = create_ssh_client(instance_ip, username, key_file)
            chmod_command = "chmod 400 ~/.ssh/id_rsa"
            stdout, stderr = run_command(ssh, chmod_command)
            if stderr:
                print(f"Error setting permissions on SSH key: {stderr}")
            ssh.close()
            return True
        else:
            print(f"Attempt {attempt + 1} failed: Error transferring SSH key with scp command: {scp_command}")
            time.sleep(30)  # Wait 30 seconds before retrying

    ssh = create_ssh_client(instance_ip, username, key_file)
    known_hosts_cmd = f"echo '{GITHUB_KEY}' >> ~/.ssh/known_hosts"
    stdout, stderr = run_command(ssh, known_hosts_cmd)
    if stderr:
        print(f"Error adding GitHub key to known_hosts: {stderr}")
    else:
        print("GitHub key added to known_hosts")
    ssh.close()

def transfer_keys_to_all_instances(instances, username, local_key_path, key_file):
    for instance in instances:
        public_dns = instance.public_dns_name
        transfer_ssh_key(public_dns, username, local_key_path, key_file)

def get_ec2_instances(instance_info,aws_access_key_id,aws_secret_access_key):
    instances = []
    for info in instance_info:
        session = boto3.Session(
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            region_name=info['region']  # Utiliser la région de l'instance
        )
        ec2_resource = session.resource('ec2')
        instance = ec2_resource.Instance(info['id'])
        instances.append(instance)
    return instances

def parse_arguments():
    parser = argparse.ArgumentParser(description="Download GitHub script.")
    parser.add_argument('--aws_access_key_id', type=str, help="AWS Access Key ID")
    parser.add_argument('--aws_secret_access_key', type=str, help="AWS Secret Access Key")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_arguments()
    aws_access_key_id=args.aws_access_key_id
    aws_secret_access_key=args.aws_secret_access_key
    all_instances_info = load_instances()

    all_instances = get_ec2_instances(all_instances_info,aws_access_key_id, aws_secret_access_key)
    username = "ubuntu"
    local_key_path = "/home/zacharie/.ssh/rsa_file"
    key_file = "my-ec2-key-paire.pem"

    transfer_keys_to_all_instances(all_instances, username, local_key_path, key_file)
