#!/bin/bash

# Vérification des arguments
if [ "$#" -lt 2 ]; then
    echo "Usage: $0 <adresse_ip_diary> <nombre_de_clients>"
    exit 1
fi

ADRESSE_IP_DIARY=$1
NOMBRE_CLIENTS=$2
REPERTOIRE_PARTAGER="./repertoire_partager"
PROJET_DR="./ProjetDR"
OUT_DIR="out"
SRC_DIR="src"

# Création des répertoires nécessaires
mkdir -p "$OUT_DIR"
mkdir -p "$REPERTOIRE_PARTAGER"

# Compilation des fichiers Java
echo "Compilation des fichiers Java..."
javac -source 17 -target 17 -d "$OUT_DIR" -sourcepath "$SRC_DIR" \
    "$SRC_DIR/Diary/DiaryServer.java" \
    "$SRC_DIR/daemon/Daemon.java" \
    "$SRC_DIR/model/"*.java \
    "$SRC_DIR/interfaces/"*.java \
    "$SRC_DIR/downloader/Downloader.java" \
    "$SRC_DIR/model/ClientMain.java"

if [ $? -ne 0 ]; then
    echo "Erreur lors de la compilation. Veuillez vérifier vos fichiers Java."
    exit 1
fi

echo "Compilation terminée avec succès."

# Instructions de lancement
echo -e "\n=== Instructions ==="
echo "1. Ouvrez un terminal pour démarrer le serveur :"
echo "   java -cp $OUT_DIR Diary.DiaryServer"
echo ""
echo "2. Ouvrez $NOMBRE_CLIENTS terminaux pour les clients. Dans chaque terminal, exécutez :"
for ((i=1; i<=NOMBRE_CLIENTS; i++)); do
    CLIENT_DIR="$PROJET_DR/shared$i"
    mkdir -p "$CLIENT_DIR"
    
    # Copier les fichiers du répertoire partagé vers le répertoire client
    cp -r "$REPERTOIRE_PARTAGER/"* "$CLIENT_DIR/"
    
    echo "   java -cp $OUT_DIR model.ClientMain $ADRESSE_IP_DIARY $CLIENT_DIR"
done