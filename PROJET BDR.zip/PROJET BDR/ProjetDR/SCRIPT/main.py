import time
import subprocess
import argparse

# def run_script(script_name):
#     try:
#         print(f"Running {script_name}...")
#         result = subprocess.run(['python', script_name], check=True)
#         print(f"{script_name} completed successfully with exit code {result.returncode}.")
#     except subprocess.CalledProcessError as e:
#         print(f"Error occurred while running {script_name}: {e}")


def run_script(script_name, aws_access_key_id, aws_secret_access_key):
    try:
        print(f"Running {script_name} with AWS credentials...")
        result = subprocess.run(
            ['python', script_name, '--aws_access_key_id', aws_access_key_id, '--aws_secret_access_key', aws_secret_access_key], 
            check=True
        )
        print(f"{script_name} completed successfully with exit code {result.returncode}.")
    except subprocess.CalledProcessError as e:
        print(f"Error occurred while running {script_name}: {e}")

def parse_arguments():
    parser = argparse.ArgumentParser(description="Run scripts with AWS credentials.")
    parser.add_argument('--aws_access_key_id', type=str, default='AKIAYDWHTDEGZUQHKVXP', help="AWS Access Key ID")
    parser.add_argument('--aws_secret_access_key', type=str, default='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', help="AWS Secret Access Key")
    return parser.parse_args()

if __name__ == "__main__":
     # Récupérer les arguments en ligne de commande
    args = parse_arguments()

    scripts = [
        #'init_instance.py',
        #'shared_ssh_github.py',
        #'install_dependance.py',
        #'download_github.py',
        #'launch_client.py'
        'n7.py'
    ]

    for script in scripts:
        # run_script(script)
        # print("Waiting for 60 seconds before running the next script...")  
        run_script(script, args.aws_access_key_id, args.aws_secret_access_key)
        print("Waiting for 60 seconds before running the next script...")
        time.sleep(60)
