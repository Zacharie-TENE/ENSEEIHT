#!/bin/bash


AWS_ACCESS_KEY_ID="AKIAYDWHTDEGZUQHKVXP"
AWS_SECRET_ACCESS_KEY="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"


python3 n7_aws.py --aws_access_key_id "$AWS_ACCESS_KEY_ID" --aws_secret_access_key "$AWS_SECRET_ACCESS_KEY"

