import boto3

# Liste des régions
regions = [
    'eu-central-1', 'eu-west-3', 'eu-west-1', 'eu-west-2', 'eu-north-1', 'sa-east-1',
    'ap-south-1', 'ap-northeast-3', 'ap-northeast-2', 'ap-northeast-1',
    'ap-southeast-1', 'ap-southeast-2', 'ca-central-1',
    'us-east-2', 'us-east-1', 'us-west-2', 'us-west-1'
]

def check_instance_type(region, instance_type='t2.micro'):
    # Créer une session EC2 pour la région donnée
    ec2_client = boto3.client('ec2', region_name=region)

    try:
        # Vérifier si l'instance t2.micro est disponible dans la région
        response = ec2_client.describe_instance_types(InstanceTypes=[instance_type])
        if response['InstanceTypes']:
            print(f"Instance {instance_type} est disponible dans la région {region}")
        else:
            print(f"Instance {instance_type} n'est pas disponible dans la région {region}")
    except Exception as e:
        print(f"Erreur lors de la vérification de {instance_type} dans la région {region}: {e}")

def main():
    for region in regions:
        check_instance_type(region)

if __name__ == "__main__":
    main()
