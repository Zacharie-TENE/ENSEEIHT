import paramiko
import json
import boto3
import argparse
# Inclure les fonctions et le code de lancement du projet ici

def load_instances():
    with open('instances.json', 'r') as f:
        return json.load(f)
    
def create_ssh_client(instance_ip, username, key_file):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(instance_ip, username=username, key_filename=key_file)
    return ssh

def run_command(ssh, command):
    stdin, stdout, stderr = ssh.exec_command(command)
    exit_status = stdout.channel.recv_exit_status()
    if exit_status != 0:
        print(f"Command '{command}' failed with exit status {exit_status}")
    return stdout.read().decode(), stderr.read().decode()

def deploy_and_run_project(ssh, project_dir, server_ip, shared_dir):
    print("Deploying project...")
    run_cmd = f"java -cp {"ProjetDR"}/out model.ClientMain {server_ip} {shared_dir}"
    stdout, stderr = run_command(ssh, run_cmd)
    if stderr:
        print(f"Error running ClientMain: {stderr}")
    else:
        print(f"ClientMain output: {stdout}")

def run_project_on_all_instances(instances, username, key_file, project_dir, server_ip, shared_dir):
    for instance in instances:
        public_dns = instance.public_dns_name
        ssh = create_ssh_client(public_dns, username, key_file)
        deploy_and_run_project(ssh, project_dir, server_ip, shared_dir)
        ssh.close()

def get_ec2_instances(instance_info,aws_access_key_id,aws_secret_access_key):
    instances = []
    for info in instance_info:
        session = boto3.Session(
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            region_name=info['region']  # Utiliser la région de l'instance
        )
        ec2_resource = session.resource('ec2')
        instance = ec2_resource.Instance(info['id'])
        instances.append(instance)
    return instances

def parse_arguments():
    parser = argparse.ArgumentParser(description="Download GitHub script.")
    parser.add_argument('--aws_access_key_id', type=str, help="AWS Access Key ID")
    parser.add_argument('--aws_secret_access_key', type=str, help="AWS Secret Access Key")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_arguments()
    aws_access_key_id=args.aws_access_key_id
    aws_secret_access_key=args.aws_secret_access_key
    all_instances_info = load_instances()


    all_instances = get_ec2_instances(all_instances_info,aws_access_key_id, aws_secret_access_key)

    username = "ubuntu"
    key_file = "my-ec2-key-paire.pem"
    project_dir = "~/projet"
    shared_dir = "ProjetDR/shared_dir"
    server_ip = input("Enter the RMI server IP: ")
    run_project_on_all_instances(all_instances, username, key_file, project_dir, server_ip, shared_dir)