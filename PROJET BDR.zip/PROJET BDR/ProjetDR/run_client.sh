#!/bin/bash
SHARED_DIR="$1"
SERVER_IP="$2"
cd "$(dirname "$0")"
java -cp out model.ClientMain "$SERVER_IP" "$SHARED_DIR" 0
