# # Vérifier si le nombre d'instances est fourni
# if [ -z "$1" ]; then
#     echo "Usage: $0 <number_of_instances>"
#     exit 1
# fi

# NUM_INSTANCES=$1

# # Vérifier si le répertoire shared1 existe
# if [ ! -d "shared1" ]; then
#     echo "Le répertoire shared1 n'existe pas."
#     exit 1
# fi

# # Créer les répertoires partagés
# for ((i=1; i<=NUM_INSTANCES; i++)); do
#     mkdir -p "shared$i"
#     if [ $i -ne 1 ]; then
#         cp -r shared1/* "shared$i/"
#     fi
# done

# # Obtenir le chemin absolu du répertoire actuel
# CURRENT_DIR=$(pwd)

# # Créer le script run_client.sh s'il n'existe pas
# cat > "$CURRENT_DIR/run_client.sh" << 'EOF'
# #!/bin/bash
# SHARED_DIR="$1"
# cd "$(dirname "$0")"
# java -cp out model.ClientMain 10.192.116.133 "$SHARED_DIR" 0
# EOF

# # Rendre le script exécutable
# chmod +x "$CURRENT_DIR/run_client.sh"

# # Lancer les instances dans des terminaux séparés
# for ((i=1; i<=NUM_INSTANCES; i++)); do
#     SHARED_DIR="shared$i"
#     gnome-terminal -- bash -c "cd '$CURRENT_DIR' && ./run_client.sh $SHARED_DIR; exec bash"
# done

#!/bin/bash

# Vérifier si le nombre d'instances est fourni
if [ -z "$1" ]; then
    echo "Usage: $0 <number_of_instances> [server_ip]"
    exit 1
fi

NUM_INSTANCES=$1
SERVER_IP="$2"

# Vérifier si le répertoire shared1 existe
if [ ! -d "shared1" ]; then
    echo "Le répertoire shared1 n'existe pas."
    exit 1
fi

# Créer les répertoires partagés
for ((i=1; i<=NUM_INSTANCES; i++)); do
    mkdir -p "shared$i"
    if [ $i -ne 1 ]; then
        cp -r shared1/* "shared$i/"
    fi
done

# Obtenir le chemin absolu du répertoire actuel
CURRENT_DIR=$(pwd)

# Créer le script run_client.sh s'il n'existe pas
cat > "$CURRENT_DIR/run_client.sh" << 'EOF'
#!/bin/bash
SHARED_DIR="$1"
SERVER_IP="$2"
cd "$(dirname "$0")"
java -cp out model.ClientMain "$SERVER_IP" "$SHARED_DIR" 0
EOF

# Rendre le script exécutable
chmod +x "$CURRENT_DIR/run_client.sh"

# Lancer les instances dans des terminaux séparés
for ((i=1; i<=NUM_INSTANCES; i++)); do
    SHARED_DIR="shared$i"
    gnome-terminal -- bash -c "cd '$CURRENT_DIR' && ./run_client.sh $SHARED_DIR $SERVER_IP; exec bash"
done




