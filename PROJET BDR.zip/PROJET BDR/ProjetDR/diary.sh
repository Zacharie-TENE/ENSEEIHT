#!/bin/bash
# launch_diary_server.sh

# Obtenir le répertoire actuel
CURRENT_DIR=$(pwd)


# Vérifier si la compilation a réussi
if [ $? -ne 0 ]; then
    echo "Erreur lors de la compilation"
    exit 1
fi

# Obtenir l'adresse IP du serveur si fournie en argument
SERVER_IP="$1"

# Si aucune adresse IP n'est fournie, obtenir l'adresse IP locale
if [ -z "$SERVER_IP" ]; then
    SERVER_IP=$(hostname -I | awk '{print $1}')
fi

# Lancer le serveur
echo "Lancement du serveur Diary sur IP $SERVER_IP..."
java -cp out Diary.DiaryServer "$SERVER_IP"