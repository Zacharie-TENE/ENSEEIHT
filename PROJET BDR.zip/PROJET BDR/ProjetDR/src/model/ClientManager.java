// ClientManager pour gérer l'état du client
package model;

import interfaces.DiaryInterface;
import java.util.Timer;
import java.util.TimerTask;

public class ClientManager {
    private final Client client;
    private final DiaryInterface diary;
    private final Timer heartbeatTimer;
    private static final long HEARTBEAT_INTERVAL =30000; // 30 seconds

    public ClientManager(Client client, DiaryInterface diary) {
        this.client = client;
        this.diary = diary;
        this.heartbeatTimer = new Timer(true);
    }

    protected void startHeartbeat() {
        heartbeatTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                try {
                    diary.updateClientStatus(client.getId(), true);
                    client.updateLastSeen();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 0, HEARTBEAT_INTERVAL);
    }

    public void shutdown() {
        try {
            heartbeatTimer.cancel();
            diary.updateClientStatus(client.getId(), false);
            diary.unregisterClient(client);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Client getClient() {
        return client;
    }


    public void updateLoad(int currentLoad) {
        try {
            diary.updateClientLoad(client.getId(), currentLoad);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    



 
}