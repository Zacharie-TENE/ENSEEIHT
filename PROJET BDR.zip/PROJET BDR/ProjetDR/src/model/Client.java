package model;
import java.io.Serializable;
import java.util.UUID;

public class Client implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private final String id;
    private final String name;
    private final String ip;
    private final int port;
    private boolean isActive;
    private long lastSeen;
    
    public Client(String name, String ip, int port) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.ip = ip;
        this.port = port;
        this.isActive = true;
        this.lastSeen = System.currentTimeMillis();
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getIp() {
        return ip;
    }

    public int getPort() {
        return port;
    }

    public boolean isActive() {
        return isActive;
    }

    public long getLastSeen() {
        return lastSeen;
    }

    // Setters
    public void setActive(boolean active) {
        this.isActive = active;
    }

    public void updateLastSeen() {
        this.lastSeen = System.currentTimeMillis();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Client client = (Client) o;
        return id.equals(client.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        return "Client{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", ip='" + ip + '\'' +
                ", port=" + port +
                ", active=" + isActive +
                '}';
    }

    // Builder pattern pour une création plus flexible
    public static class Builder {
        private String name;
        private String ip;
        private int port;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder ip(String ip) {
            this.ip = ip;
            return this;
        }

        public Builder port(int port) {
            this.port = port;
            return this;
        }

        public Client build() {
            if (name == null || ip == null || port <= 0) {
                throw new IllegalStateException("Missing required client properties");
            }
            return new Client(name, ip, port);
        }
    }
}
