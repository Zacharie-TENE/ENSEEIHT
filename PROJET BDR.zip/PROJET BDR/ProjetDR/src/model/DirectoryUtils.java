package model;

import java.nio.file.*;


public class DirectoryUtils {
    public static boolean  createDirectoryIfNotExists(String path) {
        Path directoryPath = Paths.get(path);

        try {
            // Vérifie si le répertoire existe ou non
            if (!Files.exists(directoryPath)) {
                // Crée le répertoire et tous les répertoires parents nécessaires
                Files.createDirectories(directoryPath);
                System.out.println("Shared folder created: " + directoryPath.toAbsolutePath());
                return false;
            } else if (!Files.isDirectory(directoryPath)) {
                // Si le chemin existe mais n'est pas un répertoire, lever une exception
                System.err.println("Shared directory does not exist or is not a directory: " + path);
                return false;
            }
        } catch (Exception e) {
            throw new RuntimeException("Impossible to create the directory: " + path, e);
        }
        
    return true;

    }

}
