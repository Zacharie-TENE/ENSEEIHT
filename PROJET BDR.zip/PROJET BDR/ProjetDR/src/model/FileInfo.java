// FileInfo.java
package model;

import java.io.Serializable;

public class FileInfo implements Serializable {
    private String fileName;
    private long fileSize;
    private String checksum;
    private boolean isCompressed;

    public FileInfo(String fileName, long fileSize, String checksum, boolean isCompressed) {
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.checksum = checksum;
        this.isCompressed = isCompressed;
    }

    // Getters and setters
    public String getFileName() { return fileName; }
    public long getFileSize() { return fileSize; }
    public String getChecksum() { return checksum; }
    public boolean isCompressed() { return isCompressed; }
}