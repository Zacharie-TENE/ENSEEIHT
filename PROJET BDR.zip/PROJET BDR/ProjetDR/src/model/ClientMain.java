package model;

import daemon.Daemon;
import daemon.FileHandler;
import downloader.Downloader;
import interfaces.DiaryInterface;
import java.io.IOException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
//import java.rmi.Naming;
public class ClientMain {

    private static final int DEFAULT_PORT = 8080;
    private static final int MAX_PARALLEL_DOWNLOADS =200;
    private static String DIARY_HOST = "localhost";

    public static void main(String[] args) {

        String downloadDirectory = "temp_dir";
        String sharedDirectory;
        int v=1;

        if (args.length==3){
            v=0;
        }
       
        if (args.length < 2) {
            System.out.println("Warning: Usage: java ClientMain <diaryHost> <sharedDirectory>");
            System.out.println("Default values will be used: diaryHost='localhost', sharedDirectory='shared'.");
            DIARY_HOST =  args[0];
            sharedDirectory = "shared";
        } else {
            DIARY_HOST = args[0];  // Le premier argument est l'hôte RMI
            sharedDirectory = args[1]; // Le deuxième argument est le répertoire partagé
        }
        // Vérifier et créer ldu épertoires si nécessaire
        DirectoryUtils.createDirectoryIfNotExists(sharedDirectory);
        ExecutorService executorService = Executors.newFixedThreadPool(4); // 4 threads pour chaque activité principale
    


        try {
       
   
            // Création du client local
            Client client = ClientFactory.createLocalClient(DEFAULT_PORT,v);

                 System.out.println("Client ID: " + client.getId());
                 System.out.println("Client Name: " + client.getName());
              

                      // Obtenir une référence au registre RMI
            Registry registry = LocateRegistry.getRegistry(DIARY_HOST, 1099);
            
            // // Rechercher l'objet Diary
            DiaryInterface diary = (DiaryInterface) registry.lookup("Diary");
            // Connexion au serveur Diary
           // DiaryInterface diary = (DiaryInterface) Naming.lookup("rmi://" + DIARY_HOST + "/Diary");

            // Enregistrement du client auprès du serveur Diary
            diary.registerClient(client);

            // Création du Daemon (partage des fichiers)
            Daemon daemon = new Daemon(sharedDirectory, client.getPort(), false);
            executorService.submit(() -> {
                try {
                    daemon.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            // Création du FileHandler pour gérer les fichiers partagés
            FileHandler fileHandler = new FileHandler(sharedDirectory, diary,client.getId());
       
            // Création du ClientManager pour gérer l'état du client
            ClientManager clientManager = new ClientManager(client, diary);

               // Exécution du ClientManager dans un thread séparé pour gérer les battements de cœur
            executorService.submit(() -> {
                try {
                    clientManager.startHeartbeat();
                } catch (Exception e) {
                }
            });

            // Thread pour surveiller les nouveaux fichiers et les enregistrer auprès du serveur RMI
            executorService.submit(() -> {
                try {
                    while (true) {
                        fileHandler.updateDiary();  // Met à jour les fichiers partagés
                        Thread.sleep(100); // Vérifie toutes les demi-secondes
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });

            // Thread pour exécuter le menu du Downloader (téléchargement des fichiers)
            executorService.submit(() -> {
                try {
                    Downloader downloader = new Downloader(downloadDirectory,sharedDirectory,diary, MAX_PARALLEL_DOWNLOADS);
                    ClientMenu menu = new ClientMenu(downloader);
                    menu.displayMenu(); // Affiche le menu pour l'interaction avec l'utilisateur
                } catch (Exception e) {
                    System.err.println("Error in downloader thread: " + e.getMessage());
                }
            });

            // Attendre que tous les threads terminent avant de fermer l'application
            executorService.shutdown();
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow(); // Arrête tous les threads si le délai d'attente est dépassé
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            
            executorService.shutdown();
        }
    }



}