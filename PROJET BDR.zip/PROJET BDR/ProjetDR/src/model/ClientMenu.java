package model;

import downloader.Downloader;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class ClientMenu {
    private final Downloader downloader;
    private final Scanner scanner;
    private final Map<String, Long> availableFiles;
       

    public ClientMenu(Downloader downloader) {
        this.downloader = downloader;
        this.scanner = new Scanner(System.in);
        this.availableFiles = new ConcurrentHashMap<>();
    }

    public void displayMenu() {
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Enter the name of the file to download");
            System.out.println("2. View all available files in the directory");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            
            int choice = getIntInput();
            
            try {
                switch (choice) {
                    case 1:
                        enterFileName();
                        break;
                    case 2:
                        viewAllFiles();
                        break;
                    case 3:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (Exception e) {
                System.err.println("An error occurred: " + e.getMessage());
            }
        }
    }

    private void enterFileName() {
        System.out.print("Enter the name of the file to download: ");
        String fileName = scanner.nextLine();
    
            try {
              
                System.out.println("Downloading file: " + fileName);
                downloader.downloadFile(fileName);

     
    
            } catch (Exception e) {
                    System.err.println("\nFailed to download file: " + e.getMessage());
            } 
    }



    private void viewAllFiles() {
        try {
            availableFiles.clear();
            availableFiles.putAll(downloader.getAllFiles());
            if (availableFiles.isEmpty()) {
                System.out.println("No files available.");
            } else {
                System.out.println("Available files:");
                for (Map.Entry<String, Long> entry : availableFiles.entrySet()) {
                    System.out.println("File: " + entry.getKey() + " (Size: " + entry.getValue() + " bytes)");
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to retrieve available files: " + e.getMessage());
        }
    }

    private int getIntInput() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Please enter a number: ");
            }
        }
    }
}