package model;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.URL;


public class ClientFactory {
    private static final String TOKEN_URL = "http://169.254.169.254/latest/api/token";
    private static final String PUBLIC_IP_URL = "http://169.254.169.254/latest/meta-data/public-ipv4";

    public static Client createLocalClient(int port,int v) throws IOException {
        String hostname = InetAddress.getLocalHost().getHostName();
        String ip ;
        if (v==0){
        ip  = InetAddress.getLocalHost().getHostAddress();
        }
       else {
           ip = getPublicIp();


       }
       
    
        if (!isPortAvailable(port)) {
            port=getRandomAvailablePort();
        }
        
        return new Client.Builder()
                .name(hostname)
                .ip(ip)
                .port(port)
                .build();
    }
    
    public static Client createClient(String name, String ip, int port) {
        return new Client.Builder()
                .name(name)
                .ip(ip)
                .port(port)
                .build();
    }


       /**
     * Génère un port aléatoire et vérifie s'il est disponible.
     * 
     * @return Un numéro de port disponible.
     */
    protected static int getRandomAvailablePort() {
        int port;
        while (true) {
            port = (int) (Math.random() * (65535 - 1024)) + 1024; // Génère un port entre 1024 et 65535
            if (isPortAvailable(port)) {
                break;
            }
        }
        return port;
    }

    /**
     * Vérifie si un port est disponible.
     * 
     * @param port Le numéro du port à vérifier.
     * @return true si le port est disponible, false sinon.
     */
    private static boolean isPortAvailable(int port) {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            serverSocket.setReuseAddress(true);
            return true; // Le port est disponible
        } catch (IOException e) {
            return false; // Le port est déjà utilisé ou inaccessible
        }
    }

    /**
     * Obtient l'adresse IP publique de l'instance AWS.
     * 
     * @return L'adresse IP publique.
     * @throws IOException En cas d'erreur lors de la récupération de l'adresse IP.
     */
    private static String getPublicIp() throws IOException {
        String token = getToken();
        if (token == null) {
            throw new IOException("Failed to retrieve IMDSv2 token.");
        }

        URL url = new URL(PUBLIC_IP_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("X-aws-ec2-metadata-token", token);

        try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            return in.readLine();
        }
    }

    /**
     * Obtient le jeton IMDSv2.
     * 
     * @return Le jeton IMDSv2.
     * @throws IOException En cas d'erreur lors de la récupération du jeton.
     */
    private static String getToken() throws IOException {
        URL url = new URL(TOKEN_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("PUT");
        conn.setRequestProperty("X-aws-ec2-metadata-token-ttl-seconds", "21600");

        try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            return in.readLine();
        }
    }
}