// Daemon.java, responsable des connexions entrantes pour telechargement
package daemon;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.GZIPOutputStream;

public class Daemon {
    private final String sharedDirectory;
    private final int port;
    private final ExecutorService executorService;
    private final boolean useCompression;
    private volatile boolean running;

    public Daemon(String sharedDirectory, int port, boolean useCompression) {
        this.sharedDirectory = sharedDirectory;
        this.port = port;
        this.useCompression = useCompression;
        this.executorService = Executors.newFixedThreadPool(10);
        this.running = true;
    }

    public void start() throws IOException {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            serverSocket.setReuseAddress(true);
            
            while (running) {
                Socket clientSocket = serverSocket.accept();//bloquue,attend une connexion
                executorService.submit(() -> handleClient(clientSocket));
                //new Thread(() -> handleClient(clientSocket)).start();
            }
        } finally {
            shutdown();
        }
    }

    private void handleClient(Socket clientSocket) {
    try (DataInputStream in = new DataInputStream(clientSocket.getInputStream());
         DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream())) {
        
        String fileName = in.readUTF();
        long offset = in.readLong();
        long length = in.readLong();

        File file = new File(sharedDirectory, fileName);
        if (!file.exists() || !file.isFile()) {
            out.writeInt(-1);
            return;
        }

        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            byte[] buffer = new byte[8192];
            raf.seek(offset);
            
            // Calcul du checksum pour le fragment
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            ByteArrayOutputStream dataBuffer = new ByteArrayOutputStream();
            
            long remaining = Math.min(length, file.length() - offset);
            while (remaining > 0) {
                int read = raf.read(buffer, 0, (int) Math.min(buffer.length, remaining));
                if (read == -1) break;
                dataBuffer.write(buffer, 0, read);
                remaining -= read;
            }
            
            byte[] fragmentData = dataBuffer.toByteArray();
            byte[] checksum = digest.digest(fragmentData);
            
            // Envoyer le checksum d'abord
            out.writeInt(checksum.length);
            out.write(checksum);
            
            // Puis envoyer les données
            OutputStream outputStream = useCompression ? 
                new GZIPOutputStream(out) : out;
            outputStream.write(fragmentData);
            
            if (useCompression) {
                ((GZIPOutputStream) outputStream).finish();
            }
            outputStream.flush();
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}
 
    public void shutdown() {
        running = false;
        executorService.shutdown();
    }




    
}