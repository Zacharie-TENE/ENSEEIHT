package daemon;

import interfaces.DiaryInterface;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import model.DirectoryUtils;
import model.FileInfo;

public final class FileHandler {
    private final String sharedDirectory;
    private final String name;
    private DiaryInterface diary;
    private final ConcurrentMap<String, FileInfo> registeredFiles;

    public FileHandler(String sharedDirectory, DiaryInterface diary, String clientId) throws Exception {
        this.sharedDirectory = sharedDirectory;
        this.name = clientId;
        this.diary = diary;
        this.registeredFiles = new ConcurrentHashMap<>();
        registerSharedFiles();
    }

    /**
     * Enregistre les fichiers partagés dans le diary.
     */
    public void registerSharedFiles() {    
            //File directory = new File(sharedDirectory);
            Path directory = Paths.get(sharedDirectory);
            if (!DirectoryUtils.createDirectoryIfNotExists(sharedDirectory)) {
                return;
            }

            //File[] files = directory.listFiles();
            try( DirectoryStream<Path> files = Files.newDirectoryStream(directory)){
                if (files != null) {
                    for (Path file : files) {
                        if (Files.isRegularFile(file)) {
                            FileInfo fileInfo = new FileInfo(file.getFileName().toString(), Files.size(file), "", false);
                            diary.registerFile(name, fileInfo);
                            registeredFiles.put(file.getFileName().toString(), fileInfo);
                        }
                    }
                }
       
    
               } catch (Exception e) {
            System.err.println("Failed to register shared files: " + e.getMessage());
        }
    }

    /**
     * Supprime un ensemble de fichiers du diary.
     */
    public void unregisterFiles(List<String> fileNames) {
        try {
            for (String fileName : fileNames) {
                diary.unregisterFile(name, fileName);
                registeredFiles.remove(fileName);
            }
        } catch (RemoteException e) {
            System.err.println("Failed to unregister files: " + e.getMessage());
        }
    }

    /**
     * Met à jour le diary avec les fichiers actuels dans le répertoire partagé.
     */
    public void updateDiary() {
        try {
           // File directory = new File(sharedDirectory);
            Path directory = Paths.get(sharedDirectory);
            List<String> currentFileNames = new ArrayList<>();

            //File[] files = directory.listFiles();
           try( DirectoryStream<Path> files = Files.newDirectoryStream(directory)){

            if (files != null) {
                for (Path file : files) {
                    // if (file.isFile()) {
                    //     currentFileNames.add(file.getName());
                    // }

                    if (Files.isRegularFile(file)) {
                        currentFileNames.add(file.getFileName().toString());
                    }
                }
            }

           }catch(IOException e){System.err.println("Failed to update diary: " + e.getMessage());}

            List<String> filesToRegister = new ArrayList<>();
            List<String> filesToUnregister = new ArrayList<>(registeredFiles.keySet());

            for (String fileName : currentFileNames) {
                if (!registeredFiles.containsKey(fileName)) {
                    filesToRegister.add(fileName);
                } else {
                    filesToUnregister.remove(fileName);
                }
            }

            if (!filesToRegister.isEmpty()) {
                for (String fileName : filesToRegister) {
                  //  File file = new File(sharedDirectory, fileName);
                    Path file = directory.resolve(fileName);

                    FileInfo fileInfo = new FileInfo(fileName, Files.size(file), "", false);
                    diary.registerFile(name, fileInfo);
                    registeredFiles.put(fileName, fileInfo);
                }
            }

            if (!filesToUnregister.isEmpty()) {
                for (String fileName : filesToUnregister) {
                    diary.unregisterFile(name, fileName);
                    registeredFiles.remove(fileName);
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to update registry: " + e.getMessage());
        }
    }


}