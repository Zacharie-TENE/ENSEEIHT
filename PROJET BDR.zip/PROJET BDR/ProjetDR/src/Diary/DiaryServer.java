package Diary;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class DiaryServer {

    private static final String TOKEN_URL = "http://169.254.169.254/latest/api/token";
    private static final String PUBLIC_IP_URL = "http://169.254.169.254/latest/meta-data/public-ipv4";

    public static void main(String[] args) throws IOException {
        String serverIP= "localhost"; 
        if (args.length < 1) {
            System.err.println("Usage: java DiaryServer <host>");
            serverIP=getPublicIp();

            System.out.println("Default values will be used: "+serverIP);

            //System.exit(1);
        }
        else{
            serverIP = args[0];
        }
       
        
        try {

            // Définir les propriétés de sécurité
            System.setProperty("java.rmi.server.hostname", serverIP);
            System.setProperty("java.rmi.server.useLocalHostname", "false");
            // Autoriser les connexions distantes au registre
            System.setProperty("java.rmi.server.useCodebaseOnly", "false");
         
            // Create and start RMI registry on port 1099
            Registry registry = LocateRegistry.createRegistry(1099);
           
            // Create Diary instance
            DiaryImpl diary = new DiaryImpl();
            // DiaryInterface diary = new DiaryImpl();
            
            // Bind Diary to registry
            //String bindLocation = "rmi://" + serverIP + "/Diary";
            String bindLocation = "Diary";
            
            registry.rebind(bindLocation, diary);
           
            //Naming.rebind(bindLocation, diary);
            System.out.println("Diary server is running...");  
            
            System.out.println("RMI Server started");
        } catch (Exception e) {
            System.err.println("RMI Server error: " + e.getMessage());
            e.printStackTrace();
        }
    }


      /**
     * Obtient l'adresse IP publique de l'instance AWS.
     * 
     * @return L'adresse IP publique.
     * @throws IOException En cas d'erreur lors de la récupération de l'adresse IP.
     */
    private static String getPublicIp() throws IOException {
        String token = getToken();
        if (token == null) {
            throw new IOException("Failed to retrieve IMDSv2 token.");
        }

        URL url = new URL(PUBLIC_IP_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("X-aws-ec2-metadata-token", token);

        try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            return in.readLine();
        }
    }

    /**
     * Obtient le jeton IMDSv2.
     * 
     * @return Le jeton IMDSv2.
     * @throws IOException En cas d'erreur lors de la récupération du jeton.
     */
    private static String getToken() throws IOException {
        URL url = new URL(TOKEN_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("PUT");
        conn.setRequestProperty("X-aws-ec2-metadata-token-ttl-seconds", "21600");

        try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            return in.readLine();
        }
    }
}