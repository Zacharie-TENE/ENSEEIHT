// DiaryImpl.java
package Diary;

import interfaces.DiaryInterface;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import model.Client;
import model.FileInfo;

public class DiaryImpl extends UnicastRemoteObject implements DiaryInterface {
    private Map<String, Client> connectedClients;
    private Map<String, Map<String, FileInfo>> clientFiles;
    private Map<String, Integer> clientLoads;
    private Map<String, Long> lastHeartbeat;

    public DiaryImpl() throws RemoteException {
        super();
        this.connectedClients = new ConcurrentHashMap<>();
        this.clientFiles = new ConcurrentHashMap<>();
        this.clientLoads = new ConcurrentHashMap<>();
        this.lastHeartbeat = new ConcurrentHashMap<>();
        
        // nettoyer les clients inactifs
        startCleanupThread();
    }

    private void startCleanupThread() {
        Thread cleanupThread = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(300000); // verifie tous les 5 min
                    cleanup();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        cleanupThread.setDaemon(true);
        cleanupThread.start();
    }

    private void cleanup() {
        long currentTime = System.currentTimeMillis();
        lastHeartbeat.forEach((clientId, lastTime) -> {
            if (currentTime - lastTime > 300000) { 
                removeClient(clientId);
            }
        });
    }

    private void removeClient(String clientId) {
        connectedClients.remove(clientId);
        clientFiles.remove(clientId);
        clientLoads.remove(clientId);
        lastHeartbeat.remove(clientId);

        /*** */
        System.out.println("Client deregistered: " + clientId);
        displayConnectedClients();
    }

    @Override
    public void registerClient(Client client) throws RemoteException {
        System.out.println("Client registered: " + client.getId());
        displayConnectedClients();

        connectedClients.put(client.getId(), client);
        clientFiles.putIfAbsent(client.getId(), new ConcurrentHashMap<>());
        clientLoads.put(client.getId(), 0);
        lastHeartbeat.put(client.getId(), System.currentTimeMillis());

    }

    @Override
    public void unregisterClient(Client client) throws RemoteException {
        removeClient(client.getId());
    }

    @Override
    public void registerFile(String clientId, FileInfo fileInfo) throws RemoteException {
        if (clientFiles.containsKey(clientId)) {
            clientFiles.get(clientId).put(fileInfo.getFileName(), fileInfo);
           // displayClientFiles();
        }
    }

    private void displayConnectedClients() {
        System.out.println("Connected clients and their files:");
        connectedClients.forEach((clientId, client) -> {
            System.out.println("Client ID: " + clientId);
            Map<String, FileInfo> files = clientFiles.get(clientId);
            if (files != null) {
                files.forEach((fileName, fileInfo) -> {
                    System.out.println("  File: " + fileName + " (Size: " + fileInfo.getFileSize() + " bytes)");
                });
            }
        });
    }
    
    private void displayClientFiles() {
        System.out.println("Current state of clientFiles:");
        clientFiles.forEach((clientId, files) -> {
            System.out.println("Client ID: " + clientId);
            files.forEach((fileName, fileInfo) -> {
                System.out.println("  File: " + fileName + " (Size: " + fileInfo.getFileSize() + " bytes)");
            });
        });
    }
    @Override
    public void unregisterFile(String clientId, String fileName) throws RemoteException {
        if (clientFiles.containsKey(clientId)) {
            clientFiles.get(clientId).remove(fileName);
            System.out.println("File unregistered: " + fileName);
        }
    }

    @Override
    public List<Client> getClientsWithFile(String fileName) throws RemoteException {
        List<Client> clients = new ArrayList<>();
        clientFiles.forEach((clientId, files) -> {
            if (files.containsKey(fileName)) {
                Client client = connectedClients.get(clientId);
                if (client != null) {
                    clients.add(client);
                }
            }
        });
        return clients;
    }

    @Override
    public Map<String, FileInfo> getAllFiles() throws RemoteException {
        Map<String, FileInfo> allFiles = new ConcurrentHashMap<>();
        clientFiles.values().forEach(files -> 
            files.forEach((fileName, fileInfo) -> 
                {
                allFiles.putIfAbsent(fileName, fileInfo);}
                ));
        return allFiles;
    }

    @Override
    public void updateClientStatus(String clientId, boolean isAlive) throws RemoteException {
        if (isAlive) {
            lastHeartbeat.put(clientId, System.currentTimeMillis());
        }
    }

    @Override
    public int getClientLoad(String clientId) throws RemoteException {
        return clientLoads.getOrDefault(clientId, 0);
    }

    @Override
    public void updateClientLoad(String clientId, int load) throws RemoteException {
        clientLoads.put(clientId, load);
    }


@Override
public synchronized long getFileSize(String fileName) throws RemoteException {
    for (Map<String, FileInfo> files : clientFiles.values()) {
        if (files.containsKey(fileName)) {
            return files.get(fileName).getFileSize();
        }
    }
    return 0; 

}

}