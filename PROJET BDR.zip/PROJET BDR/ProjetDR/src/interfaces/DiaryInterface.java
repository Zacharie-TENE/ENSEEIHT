
package interfaces;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;
import model.Client;
import model.FileInfo;

public interface DiaryInterface extends Remote {
    
    void registerClient(Client client) throws RemoteException;
    void unregisterClient(Client client) throws RemoteException;

    void registerFile(String clientId, FileInfo fileInfo) throws RemoteException;
    void unregisterFile(String clientId, String fileName) throws RemoteException;

    List<Client> getClientsWithFile(String fileName) throws RemoteException;
    Map<String, FileInfo> getAllFiles() throws RemoteException;
    long getFileSize(String fileName) throws RemoteException;


    void updateClientStatus(String clientId, boolean isAlive) throws RemoteException;
    int getClientLoad(String clientId) throws RemoteException;
    void updateClientLoad(String clientId, int load) throws RemoteException;
}