package downloader;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import model.Client;

public class ClientSpeedTracker {
    private final Map<Client, Double> speedHistory = new ConcurrentHashMap<>();
    
    public void updateClientSpeed(Client client, long bytesTransferred, long timeInMillis) {
        double speed = bytesTransferred / (double) timeInMillis;
        speedHistory.merge(client, speed, (old, new_) -> old * 0.7 + new_ * 0.3);
    }
    
    public Double getClientSpeed(Client client) {
        return speedHistory.getOrDefault(client, 0.0);
    }
}
