package downloader;

public class ChunkSizeCalculator {
    // Tailles de fichiers seuils
    private static final long VERY_SMALL_FILE = 1024 * 1024;         // 1 MB
    private static final long SMALL_FILE = 10 * 1024 * 1024;         // 10 MB
    private static final long MEDIUM_FILE = 100 * 1024 * 1024;       // 100 MB
    private static final long LARGE_FILE = 1024 * 1024 * 1024L;      // 1 GB
    private static final long VERY_LARGE_FILE = 10L * 1024 * 1024 * 1024L; // 10 GB
    private static final long MASSIVE_FILE = 100L * 1024 * 1024 * 1024L;   // 100 GB

    // Tailles de chunks correspondantes
    private static final int VERY_SMALL_CHUNK = 256 * 1024;          // 256 KB
    private static final int SMALL_CHUNK = 512 * 1024;               // 512 KB
    private static final int MEDIUM_CHUNK = 1024 * 1024;             // 1 MB
    private static final int LARGE_CHUNK = 4 * 1024 * 1024;          // 4 MB
    private static final int VERY_LARGE_CHUNK = 8 * 1024 * 1024;     // 8 MB
    private static final int MASSIVE_CHUNK = 16 * 1024 * 1024;       // 16 MB

    public static int calculateOptimalChunkSize(long fileSize, int availableClients) {
        // Validation des paramètres
        if (fileSize <= 0 || availableClients <= 0) {
            throw new IllegalArgumentException("File size and available clients must be positive");
        }

        // Déterminer la taille de base du chunk selon la taille du fichier
        int baseChunkSize = determineBaseChunkSize(fileSize);
        
        // Ajuster la taille en fonction du nombre de clients et de la taille du fichier
        int adjustedChunkSize = adjustForClients(baseChunkSize, availableClients, fileSize);
        
        // Calculer les limites de chunks
        ChunkLimits limits = calculateChunkLimits(fileSize, availableClients);
        
        // Ajuster la taille finale en fonction des limites
        return finalizeChunkSize(adjustedChunkSize, fileSize, limits);
    }

    private static int determineBaseChunkSize(long fileSize) {
        if (fileSize < VERY_SMALL_FILE) return VERY_SMALL_CHUNK;
        if (fileSize < SMALL_FILE) return SMALL_CHUNK;
        if (fileSize < MEDIUM_FILE) return MEDIUM_CHUNK;
        if (fileSize < LARGE_FILE) return LARGE_CHUNK;
        if (fileSize < VERY_LARGE_FILE) return VERY_LARGE_CHUNK;
        if (fileSize < MASSIVE_FILE) return MASSIVE_CHUNK;
        
        // Pour les fichiers extrêmement grands (>100GB)
        return (int) Math.min(32 * 1024 * 1024L, fileSize / 10000); // Max 32MB par chunk
    }

    private static int adjustForClients(int baseChunkSize, int availableClients, long fileSize) {
        // Ajustement de base selon le nombre de clients
  
        int adjustedSize = (int) baseChunkSize;

    
        if (fileSize > VERY_LARGE_FILE) {
            // Pour les gros fichiers, on veut des chunks plus grands si peu de clients
            if (availableClients < 5) {
                adjustedSize = Math.min(adjustedSize * 2, MASSIVE_CHUNK);
            }
            // Pour beaucoup de clients, on peut réduire la taille pour plus de parallélisme
            else if (availableClients > 20) {
                adjustedSize = adjustedSize / 2;
            }
        }

        return adjustedSize;
    }

    private static class ChunkLimits {
        final int minChunks;
        final int maxChunks;
        final int minChunkSize;
        final int maxChunkSize;

        ChunkLimits(int minChunks, int maxChunks, int minChunkSize, int maxChunkSize) {
            this.minChunks = minChunks;
            this.maxChunks = maxChunks;
            this.minChunkSize = minChunkSize;
            this.maxChunkSize = maxChunkSize;
        }
    }

    private static ChunkLimits calculateChunkLimits(long fileSize, int availableClients) {
        // Minimum chunks basé sur le nombre de clients
        int minChunks = Math.max(availableClients * 2, 8);
        
        // Maximum chunks selon la taille du fichier
        int maxChunks;
        if (fileSize > MASSIVE_FILE) {
            maxChunks = Math.max(availableClients * 8, 10000);
        } else if (fileSize > VERY_LARGE_FILE) {
            maxChunks = Math.max(availableClients * 6, 5000);
        } else {
            maxChunks = Math.max(availableClients * 4, 1000);
        }

        // Taille minimum et maximum des chunks selon la taille du fichier
        int minChunkSize = VERY_SMALL_CHUNK;
        int maxChunkSize = (fileSize > MASSIVE_FILE) ? 32 * 1024 * 1024 : MASSIVE_CHUNK;

        return new ChunkLimits(minChunks, maxChunks, minChunkSize, maxChunkSize);
    }

    private static int finalizeChunkSize(int adjustedChunkSize, long fileSize, ChunkLimits limits) {
        // Calculer le nombre de chunks avec la taille ajustée
        long calculatedChunks = fileSize / adjustedChunkSize;

        // Ajuster si nécessaire pour respecter les limites
        if (calculatedChunks < limits.minChunks) {
            adjustedChunkSize = (int) (fileSize / limits.minChunks);
        } else if (calculatedChunks > limits.maxChunks) {
            adjustedChunkSize = (int) (fileSize / limits.maxChunks);
        }

        // S'assurer que la taille est dans les limites acceptables
        adjustedChunkSize = Math.max(limits.minChunkSize, 
                                   Math.min(adjustedChunkSize, limits.maxChunkSize));

        // S'assurer que la taille du chunk ne dépasse pas la taille du fichier
        return (int) Math.min(fileSize, adjustedChunkSize);
    }
}