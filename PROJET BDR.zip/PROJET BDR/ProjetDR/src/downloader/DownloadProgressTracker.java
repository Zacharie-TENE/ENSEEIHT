package downloader;

public class DownloadProgressTracker {
    private final String fileName;
    private final long totalSize;
    private long downloadedBytes;
    private long startTime;
    private long lastUpdateTime;
    private long lastDownloadedBytes;
    private double currentSpeed;

    public DownloadProgressTracker(String fileName, long totalSize) {
        this.fileName = fileName;
        this.totalSize = totalSize;
        this.downloadedBytes = 0;
        this.startTime = System.currentTimeMillis();
        this.lastUpdateTime = startTime;
        this.lastDownloadedBytes = 0;
        this.currentSpeed = 0;
    }

    public synchronized void updateProgress(long newBytes) {
        long now = System.currentTimeMillis();
        long timeDelta = now - lastUpdateTime;
    
        if (timeDelta >= 1000) { 
            long bytesDelta = newBytes - lastDownloadedBytes;
            currentSpeed = (bytesDelta * 1000.0) / timeDelta; 
            
            lastUpdateTime = now;
            lastDownloadedBytes = newBytes;
        }
        
        this.downloadedBytes = newBytes;
    }

    public double getProgress() {
        return (downloadedBytes * 100.0) / totalSize;
    }

    public double getCurrentSpeed() {
        return currentSpeed;
    }

    public String getFormattedProgress() {
        return String.format("%.1f%%", getProgress());
    }

    public String getFormattedSpeed() {
        if (currentSpeed < 1024) {
            return String.format("%.0f B/s", currentSpeed);
        } else if (currentSpeed < 1024 * 1024) {
            return String.format("%.1f KB/s", currentSpeed / 1024);
        } else {
            return String.format("%.1f MB/s", currentSpeed / (1024 * 1024));
        }
    }

    public String getFormattedSize() {
        return String.format("%s / %s", 
            formatBytes(downloadedBytes),
            formatBytes(totalSize));
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        } else if (bytes < 1024 * 1024) {
            return String.format("%.1f KB", bytes / 1024.0);
        } else if (bytes < 1024 * 1024 * 1024) {
            return String.format("%.1f MB", bytes / (1024.0 * 1024));
        } else {
            return String.format("%.1f GB", bytes / (1024.0 * 1024 * 1024));
        }
    }
}