package downloader;

import interfaces.DiaryInterface;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.rmi.RemoteException;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import model.Client;
import model.FileInfo;



public class Downloader {
    private final ExecutorService executorService;
    private final DiaryInterface diary;
    private final Map<Client, Integer> clientLoadMap;

    private final Path downloadDirectory;
    private final Path sharedDir;
    
    private static final int MAX_RETRIES = 3;
    private static final long CLIENT_TIMEOUT = 10000; // 10 seconds
    private static final int MAX_CLIENT_LOAD = 15;


    private final Map<String, DownloadStatus> activeDownloads;
    private final ScheduledExecutorService scheduledExecutor;

    private volatile long bytesDownloaded;
    private volatile long downloadStartTime;
    private final DecimalFormat speedFormat = new DecimalFormat("#.##");

    private final ClientSpeedTracker speedTracker = new ClientSpeedTracker();



    public Downloader(String downloadDirectory, String sharedDir, DiaryInterface diary, int maxParallelDownloads) throws Exception {
        this.downloadDirectory = Paths.get(downloadDirectory);
        this.sharedDir = Paths.get(sharedDir);
        this.diary = diary;

        this.bytesDownloaded = 0;
        this.downloadStartTime = 0;

        //this.executorService = Executors.newFixedThreadPool(maxParallelDownloads);
        int coreThreads = Runtime.getRuntime().availableProcessors();
        int maxThreads = coreThreads * 2;
        this.executorService = new ThreadPoolExecutor(
            coreThreads,
            maxThreads,
            60L, TimeUnit.SECONDS,
            new LinkedBlockingQueue<>(1000),
            new ThreadFactory() {
                private final AtomicInteger threadCount = new AtomicInteger(1);
                @Override
                public Thread newThread(Runnable r) {
                    Thread thread = new Thread(r);
                    thread.setName("Downloader-Thread-" + threadCount.getAndIncrement());
                    return thread;
                }
            },
            new ThreadPoolExecutor.CallerRunsPolicy()
        );

        this.clientLoadMap = new ConcurrentHashMap<>();
        this.activeDownloads = new ConcurrentHashMap<>();
        this.scheduledExecutor = Executors.newScheduledThreadPool(1);
        
        startMaintenanceTasks();
    }

    private void startMaintenanceTasks() {
        scheduledExecutor.scheduleAtFixedRate(this::checkDownloadProgress, 1, 1, TimeUnit.SECONDS);
        scheduledExecutor.scheduleAtFixedRate(this::removeCompletedDownloads, 5, 5, TimeUnit.SECONDS);
    }

    public void downloadFile(String fileName) throws Exception {
     
        long fileSize = diary.getFileSize(fileName);
    
        if (fileSize == 0) {
            throw new IllegalStateException("File size is 0 or file not found: " + fileName);
        }

        List<Client> initialClients = diary.getClientsWithFile(fileName);
        if (initialClients.isEmpty()) {
            throw new IllegalStateException("No clients available with file: " + fileName);
        }

        //int fragmentCount = calculateOptimalFragmentCount(fileSize, initialClients.size());
        int fragmentCount = ChunkSizeCalculator.calculateOptimalChunkSize(fileSize, initialClients.size());
        long fragmentSize = fileSize / fragmentCount;

        // Create download progress tracker
        DownloadStatus status = new DownloadStatus(fileName, fragmentCount, fileSize);
        activeDownloads.put(fileName, status);

         // List to keep track of failed fragments
         List<Integer> failedFragments = new CopyOnWriteArrayList<>();

         // Start chunk downloads
        CompletableFuture<?>[] downloadFutures = new CompletableFuture[fragmentCount];

        this.bytesDownloaded = 0; // Reset bytes downloaded
        this.downloadStartTime = System.currentTimeMillis(); // Start time


        for (int i = 0; i < fragmentCount; i++) {
            final int fragmentIndex = i;
          
          
            downloadFutures[i] = CompletableFuture.runAsync(() -> {

                    if (!downloadFragmentWithRetry(fileName, fragmentIndex, fragmentSize, status, initialClients)) {
                        failedFragments.add(fragmentIndex);  // Add to failed fragments list
                    }
                //downloadFragmentWithRetry(fileName, fragmentIndex, fragmentSize, status, initialClients);
            }, executorService);
        }

         startDisplayingProgress(fileName, fileSize);


        CompletableFuture.allOf(downloadFutures).join();

        // Retry failed fragments
        for (int fragmentIndex : failedFragments) {
            downloadFragmentWithRetry(fileName, fragmentIndex, fragmentSize, status, initialClients);
        }
        
        if (!status.isFailed()) {
           
            // Effacer la ligne courante
            System.out.print("\r" + " ".repeat(80) + "\r");
            // Merge chunks and complete download
            mergeAndSaveFile(fileName, status);
            status.complete();

             // Afficher le message final une seule fois
              long totalTime = (System.currentTimeMillis() - downloadStartTime) / 1000;
              double averageSpeed = totalTime > 0 ? (fileSize / 1024.0) / totalTime : 0;
              System.out.printf("Download completed (successfully): %.1f KB at %.1f KB/s\n ", 
                  fileSize / 1024.0, averageSpeed);
        }
      
    }



    private boolean downloadFragmentWithRetry(String fileName, int fragmentIndex, long fragmentSize,
                                         DownloadStatus status, List<Client> availableClients) {
        int retryCount = 0;
        while (!status.isFailed() && retryCount < MAX_RETRIES) {

            // if (availableClients.isEmpty()) {
            //     throw new IllegalStateException("No clients available for file: " + fileName);
            // }
            
            //selectOptimalClient
            Client selectedClient = selectLeastLoadedClient(availableClients);
            if (selectedClient == null) {
                try {
                    availableClients = diary.getClientsWithFile(fileName);
                    if (availableClients.isEmpty()) {
                        throw new IllegalStateException("No available clients for file: " + fileName);
                    }
                    // Exponential backoff
                    Thread.sleep(1000L * (1 << retryCount));
                    retryCount++;
                    continue;
                } catch (Exception e) {
                    retryCount++;
                    continue;
                }
            }

            try {
               // incrementClientLoad(selectedClient);

               long fragmentStartTime = System.currentTimeMillis();
             
                byte[] data = downloadFragmentFromClient(fileName, fragmentIndex, fragmentSize, selectedClient,  status);

                long timeElapsed = System.currentTimeMillis() - fragmentStartTime;
                speedTracker.updateClientSpeed(selectedClient, data.length, timeElapsed);

                     // Update total bytes downloaded
                     synchronized (this) {
                        this.bytesDownloaded += data.length;
                    }
              
                return true;
            } catch (Exception e) {
                retryCount++;
                if (retryCount >= MAX_RETRIES) {
                    status.fail(new Exception("Failed to download fragment " + fragmentIndex  + " after " + MAX_RETRIES + " retries", e));
                }
            } finally {
                decrementClientLoad(selectedClient);
            }
        }
        return false;
    }

    private void startDisplayingProgress(String fileName, long fileSize) {
        final ScheduledFuture<?>[] progressTask = new ScheduledFuture<?>[1];
        progressTask[0] = scheduledExecutor.scheduleAtFixedRate(() -> {
            double progress = (double) bytesDownloaded / fileSize * 100;
            long elapsedTime = System.currentTimeMillis() - downloadStartTime;
            double speed = bytesDownloaded / (elapsedTime / 1000.0); // bytes per second

            
           // System.out.printf("\rDownloading %s: %.2f%% complete, Speed: %s bytes/sec", fileName, progress, speedFormat.format(speed));
            
            // Stop displaying progress if download is complete
            if (progress >= 100.0) {
               //System.out.println("\nFile downloaded successfully.");
                progressTask[0].cancel(false); // Stop the scheduled task
            }
        }, 0, 1, TimeUnit.SECONDS);

    }


    
    private byte[] downloadFragmentFromClient(String fileName, int fragmentIndex, long fragmentSize, Client client, DownloadStatus status)
            throws IOException {
        try (Socket socket = new Socket(client.getIp(), client.getPort())) {
            incrementClientLoad(client);
            socket.setSoTimeout((int) CLIENT_TIMEOUT);
            socket.setReceiveBufferSize(64 * 1024); // Augmenter la taille du buffer
            
            try (DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                 DataInputStream in = new DataInputStream(socket.getInputStream())) {

                out.writeUTF(fileName);
                out.writeLong(fragmentIndex * fragmentSize);
                out.writeLong(fragmentSize);
                out.flush();


                // Lire le checksum
                int checksumLength = in.readInt();
                byte[] checksum = new byte[checksumLength];
                in.readFully(checksum);


                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                byte[] data = new byte[64*1024];//[32 * 1024]
                int bytesRead;
                int totalRead = 0;
                
                while ((bytesRead = in.read(data, 0, data.length)) != -1) {
                    buffer.write(data, 0, bytesRead);
               
                    totalRead += bytesRead;
                    status.updateFragmentProgress(fragmentIndex, totalRead);
                }

                // return buffer.toByteArray();
                byte[] fragmentData = buffer.toByteArray();
            
                // Vérifier l'intégrité
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] calculatedChecksum = digest.digest(fragmentData);
                
                if (!Arrays.equals(calculatedChecksum, checksum)) {
                    throw new IOException("Fragment integrity check failed");
                }


                status.saveFragment(fragmentIndex, fragmentData, calculatedChecksum);

                return fragmentData;
            }catch (Exception e) {
                throw new IOException("Failed to download fragment from client", e);
            }
        }
    }

    private void checkDownloadProgress() {
        long currentTime = System.currentTimeMillis();
        activeDownloads.values().forEach(status -> {
            if (!status.isComplete() && !status.isFailed() &&
                    currentTime - status.getLastUpdateTime() > CLIENT_TIMEOUT) {
                status.fail(new Exception("Download stalled"));
            }
        });
    }

    private void removeCompletedDownloads() {
        activeDownloads.entrySet().removeIf(entry ->
                entry.getValue().isComplete() || entry.getValue().isFailed());
    }

    
    private Client selectLeastLoadedClient1(List<Client> availableClients) {
        return availableClients.stream()
            .filter(client -> {
                try {
                    return diary.getClientLoad(client.getId()) < MAX_CLIENT_LOAD;
                } catch (RemoteException e) {
                    e.printStackTrace();
                    return false;
                }
            })
            .min((c1, c2) -> {
                try {
                    return Integer.compare(diary.getClientLoad(c1.getId()), diary.getClientLoad(c2.getId()));
                } catch (RemoteException e) {
                    e.printStackTrace();
                    return Integer.MAX_VALUE;
                }
            })
            .orElse(null);
    }


private Client selectLeastLoadedClient2(List<Client> availableClients) {
    return availableClients.stream()
        .filter(client -> getClientLoad(client) < MAX_CLIENT_LOAD)
        .min((c1, c2) -> getClientLoad(c1) - getClientLoad(c2))
        .orElse(null);
}
    private int getClientLoad(Client client) {
        return clientLoadMap.getOrDefault(client, 0);
    }

    
    private Client selectLeastLoadedClient(List<Client> availableClients) {
        return availableClients.stream()
            .filter(client -> {
                try {
                    return diary.getClientLoad(client.getId()) < MAX_CLIENT_LOAD;
                } catch (RemoteException e) {
                    e.printStackTrace();
                    return false;
                }
            })
            .min((c1, c2) -> {
                try {
                    return Integer.compare(diary.getClientLoad(c1.getId()), diary.getClientLoad(c2.getId()));
                } catch (RemoteException e) {
                    e.printStackTrace();
                    return Integer.MAX_VALUE;
                }
            })
            .orElse(null);
    }

    private void incrementClientLoad(Client client) {
        try {
            diary.updateClientLoad(client.getId(), diary.getClientLoad(client.getId()) + 1);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
    private void decrementClientLoad(Client client) {
        try {
            int currentLoad = diary.getClientLoad(client.getId());
            diary.updateClientLoad(client.getId(), currentLoad - 1);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public DiaryInterface getDiary() {
        return diary;
    }

    public Map<String, Long> getAllFiles() throws RemoteException {
        Map<String, FileInfo> allFiles = diary.getAllFiles();
        Map<String, Long> fileSizes = new HashMap<>();
        for (Map.Entry<String, FileInfo> entry : allFiles.entrySet()) {
            fileSizes.put(entry.getKey(), entry.getValue().getFileSize());
        }
        return fileSizes;
    }


    private void mergeAndSaveFile(String fileName, DownloadStatus status) 
            throws IOException {

        // Vérifier l'intégrité de tous les fragments
        for (int i = 0; i < status.getTotalFragments(); i++) {
            if (!status.verifyFragmentIntegrity(i)) {
                throw new IOException("Fragment " + i + " integrity check failed");
            }
        }

        Path tempFile = downloadDirectory.resolve(fileName + ".tmp");
        Path finalFile = sharedDir.resolve(fileName);

       // Créer le fichier temporaire s'il n'existe pas
       if (Files.notExists(tempFile)) {
        
        Files.createDirectories(downloadDirectory); 
        Files.createFile(tempFile);  
    }
        
        try (FileOutputStream out = new FileOutputStream(tempFile.toFile())) {
            for (int i = 0; i < status.getTotalFragments(); i++) {
                byte[] fragment = status.getFragment(i);
                if (fragment == null) {
                    throw new IOException("Missing fragment " + i);
                }
                out.write(fragment);
            }
        }

     // Déplacement atomique du fichier temporaire vers l'emplacement final
        try {
            Files.move(tempFile, finalFile, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("finaly");
        } catch (IOException e) {
            throw new IOException("Failed to move file to final location", e);
        }

        // Suppression du fichier temporaire
        try {
            Files.deleteIfExists(tempFile);
        } catch (IOException e) {
            throw new IOException("Failed to delete temporary file", e);
        }
    }

    public void shutdown() {
        executorService.shutdown();
        scheduledExecutor.shutdown();
    }

    public void cancelDownload(String fileName) {
        DownloadStatus status = activeDownloads.get(fileName);
        if (status != null) {
            status.fail(new Exception("Download cancelled by user"));
        }
    }

    public DownloadStatus getDownloadStatus(String fileName) {
        return activeDownloads.get(fileName);
    }
 
   
 



   
}


