package downloader;


import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.*;


public class DownloadStatus {
    private final String fileName;
    private final Map<Integer, byte[]> fragments;
    private final int totalFragments;
    private volatile boolean complete;
    private volatile boolean failed;
    private volatile Exception error;
    private volatile long lastUpdateTime;

    private volatile long downloadedSize;
    private final long totalSize;
    private final Map<Integer, Long> fragmentProgress;
    private final Map<Integer, byte[]> fragmentChecksums;

    private final DownloadProgressTracker progressTracker;
    
    
    

    public DownloadStatus(String fileName, int totalFragments, long totalSize) {
        this.fileName = fileName;
        this.fragments = new ConcurrentHashMap<>();
        this.totalFragments = totalFragments;
        this.lastUpdateTime = System.currentTimeMillis();

        this.downloadedSize = 0;
        this.totalSize = totalSize;
        this.fragmentProgress = new ConcurrentHashMap<>();
        this.fragmentChecksums = new ConcurrentHashMap<>();

        this.progressTracker = new DownloadProgressTracker(fileName, totalSize);
    }

    public void saveFragment(int index, byte[] data, byte[] checksum) {
        fragmentChecksums.put(index, checksum);
        fragments.put(index, data);
        updateLastUpdateTime();
    }

    public byte[] getFragment(int index) {
        return fragments.get(index);
    }

    public void complete() {
        this.complete = true;
    }

    public void fail(Exception e) {
        this.failed = true;
        this.error = e;
    }

    public boolean isComplete() {
        return complete;
    }

    public boolean isFailed() {
        return failed;
    }

    public long getLastUpdateTime() {
        return lastUpdateTime;
    }

    private void updateLastUpdateTime() {
        this.lastUpdateTime = System.currentTimeMillis();
    }

    public Map<Integer, byte[]> getFragments() {
        return fragments;
    }

    public int getTotalFragments() {
        return totalFragments;
    }

    public long getDownloadedSize() {
        return downloadedSize;
    }
    
    public long getTotalSize() {
        return totalSize;
    }


    /*/ */
    public synchronized void updateFragmentProgress(int fragmentIndex, long bytesRead) {
        Long oldProgress = fragmentProgress.getOrDefault(fragmentIndex, 0L);
        fragmentProgress.put(fragmentIndex, bytesRead);
        downloadedSize += (bytesRead - oldProgress);

        progressTracker.updateProgress(downloadedSize);
    }

    public double getOverallProgress() {
        return totalSize > 0 ? (double) downloadedSize / totalSize * 100 : 0;
    }

    public Map<Integer, Double> getFragmentProgresses() {
        Map<Integer, Double> progress = new HashMap<>();
        long fragmentSize = totalSize / totalFragments;
        
        fragmentProgress.forEach((index, bytes) -> {
            double percentage = (double) bytes / fragmentSize * 100;
            progress.put(index, Math.min(100, percentage));
        });
        
        return progress;
    }
    
    public boolean verifyFragmentIntegrity(int index) {
        try {
            byte[] data = fragments.get(index);
            byte[] storedChecksum = fragmentChecksums.get(index);
            if (data == null || storedChecksum == null) {
                return false;
            }
            
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] calculatedChecksum = digest.digest(data);
            return Arrays.equals(calculatedChecksum, storedChecksum);
        } catch (Exception e) {
            return false;
        }
    }

    public String getCurrentSpeed() {
        return progressTracker.getFormattedSpeed();
    }

    public String getFormattedProgress() {
        return String.format("%s - %s - %s", 
            progressTracker.getFormattedProgress(),
            progressTracker.getFormattedSize(),
            progressTracker.getFormattedSpeed());
    }
    
}
