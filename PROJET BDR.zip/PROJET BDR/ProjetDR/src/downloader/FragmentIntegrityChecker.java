package downloader;

import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

public class FragmentIntegrityChecker {
    private final Map<Integer, String> fragmentHashes;
    
    public FragmentIntegrityChecker() {
        this.fragmentHashes = new HashMap<>();
    }
    
    public String calculateHash(byte[] data) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data);
        return bytesToHex(hash);
    }
    
    public void addFragmentHash(int fragmentIndex, byte[] data) throws Exception {
        fragmentHashes.put(fragmentIndex, calculateHash(data));
    }
    
    public boolean verifyFragment(int fragmentIndex, byte[] data) throws Exception {
        String originalHash = fragmentHashes.get(fragmentIndex);
        if (originalHash == null) {
            throw new IllegalStateException("No hash found for fragment " + fragmentIndex);
        }
        return originalHash.equals(calculateHash(data));
    }
    
    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}