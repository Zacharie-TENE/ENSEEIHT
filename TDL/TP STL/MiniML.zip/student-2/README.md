# Project - Sémantique et TDL

## Mini - Project : MiniML

#### Autheur

**TENE FOGANG ZACHARIE IGOR**  2A - SN.